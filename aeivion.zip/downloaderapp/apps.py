from django.apps import AppConfig


class DownloaderappConfig(AppConfig):
    name = 'downloaderapp'
