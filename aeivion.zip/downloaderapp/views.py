from django.shortcuts import render
from django.http import JsonResponse, FileResponse
import yt_dlp
import os
import threading
import uuid
import time

# In-memory storage for progress (Use Redis/Database for production)
download_progress = {}

def index(request):
    return render(request, 'index.html')

def progress_hook(d, task_id):
    """
    This function is called by yt-dlp periodically during the download.
    We use it to update the global `download_progress` dictionary.
    """
    if d['status'] == 'downloading':
        # Calculate percentage
        p = d.get('_percent_str', '0%').replace('%', '')
        download_progress[task_id] = {
            'status': 'downloading',
            'percent': p,
            'filename': None
        }
    elif d['status'] == 'finished':
        download_progress[task_id] = {
            'status': 'finished',
            'percent': '100',
            'filename': d['filename']
        }

def run_download(video_url, task_id):
    """
    The actual download logic running in a background thread.
    """
    ydl_opts = {
        'format': 'best',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        # Attach the hook to capture progress
        'progress_hooks': [lambda d: progress_hook(d, task_id)],
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
    except Exception as e:
        download_progress[task_id] = {'status': 'error', 'msg': str(e)}

def start_download(request):
    """
    Starts the thread and returns a Task ID immediately.
    """
    video_url = request.GET.get('url')
    if not video_url:
        return JsonResponse({'error': 'No URL provided'}, status=400)

    # Generate a unique ID for this download task
    task_id = str(uuid.uuid4())
    download_progress[task_id] = {'status': 'starting', 'percent': 0}

    # Start the download in a separate thread
    t = threading.Thread(target=run_download, args=(video_url, task_id))
    t.start()

    return JsonResponse({'task_id': task_id})

def get_progress(request, task_id):
    """
    Frontend polls this view to get the current status.
    """
    progress = download_progress.get(task_id, {'status': 'not_found'})
    return JsonResponse(progress)

def download_file(request, task_id):
    """
    Once finished, this view serves the file to the user.
    """
    progress = download_progress.get(task_id)
    if progress and progress['status'] == 'finished':
        file_path = progress['filename']
        return FileResponse(open(file_path, 'rb'), as_attachment=True)
    return JsonResponse({'error': 'File not ready'})
