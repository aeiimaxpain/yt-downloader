from django.shortcuts import render
from django.http import JsonResponse, FileResponse
import yt_dlp
import os
import threading
import uuid

# In-memory storage for progress (Use Redis/Database for production)
download_progress = {}

def index(request):
    return render(request, 'index.html')

def progress_hook(d, task_id):
    """
    Updates progress only for downloading. 
    We remove the 'finished' block from here because when downloading max quality, 
    yt-dlp downloads video and audio separately, which would trigger 'finished' prematurely.
    """
    if d['status'] == 'downloading':
        p = d.get('_percent_str', '0%').replace('%', '')
        download_progress[task_id] = {
            'status': 'downloading',
            'percent': p.strip(),
            'filename': None
        }

def run_download(video_url, task_id):
    """
    The actual download logic running in a background thread.
    """
    ydl_opts = {
        # Fetch the absolute best video and audio streams, fallback to best combined
        'format': 'bestvideo+bestaudio/best',
        # Force the final merged file into an MP4 container for better browser compatibility
        'merge_output_format': 'mp4',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'progress_hooks': [lambda d: progress_hook(d, task_id)],
        'quiet': True,
        'no_warnings': True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # We use extract_info with download=True so we can get the final merged filename
            info = ydl.extract_info(video_url, download=True)
            
            # yt-dlp stores the final merged file path in 'requested_downloads'
            final_file = info.get('requested_downloads', [info])[0].get('filepath')
            
            if not final_file:
                final_file = ydl.prepare_filename(info)

            # Mark as truly finished only after downloading AND merging is done
            download_progress[task_id] = {
                'status': 'finished',
                'percent': '100',
                'filename': final_file
            }
    except Exception as e:
        download_progress[task_id] = {'status': 'error', 'msg': str(e)}

def start_download(request):
    """
    Starts the thread and returns a Task ID immediately.
    """
    video_url = request.GET.get('url')
    if not video_url:
        return JsonResponse({'error': 'No URL provided'}, status=400)

    task_id = str(uuid.uuid4())
    download_progress[task_id] = {'status': 'starting', 'percent': 0}

    t = threading.Thread(target=run_download, args=(video_url, task_id))
    t.start()

    return JsonResponse({'task_id': task_id})

def get_progress(request, task_id):
    """
    Frontend polls this view to get the current status.
    """
    progress = download_progress.get(task_id, {'status': 'not_found'})
    return JsonResponse(progress)

def download_file(request, task_id):
    """
    Once finished, this view serves the file to the user.
    """
    progress = download_progress.get(task_id)
    if progress and progress['status'] == 'finished':
        file_path = progress['filename']
        if file_path and os.path.exists(file_path):
            return FileResponse(open(file_path, 'rb'), as_attachment=True)
        else:
            return JsonResponse({'error': 'File not found on server'})
    return JsonResponse({'error': 'File not ready'})
