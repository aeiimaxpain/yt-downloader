from django.apps import AppConfig


class YtdownloaderConfig(AppConfig):
    name = 'ytdownloader'
