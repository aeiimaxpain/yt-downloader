import os
import yt_dlp
from django.shortcuts import render
from django.http import FileResponse
from django.conf import settings

def download_video(request):
    context = {}
    
    if request.method == 'POST':
        video_url = request.POST.get('url')
        
        if video_url:
            # Create a folder to temporarily store the downloaded videos
            download_dir = os.path.join(settings.BASE_DIR, 'temp_downloads')
            os.makedirs(download_dir, exist_ok=True)
            
            # yt-dlp configuration options
            ydl_opts = {
                'format': 'bestvideo+bestaudio/best', # Requests highest quality video and audio
                'merge_output_format': 'mp4',         # Merges them into an mp4 file using FFmpeg
                'outtmpl': os.path.join(download_dir, '%(title)s.%(ext)s'), # File naming format
                'noplaylist': True,                   # Downloads only the single video, not the whole playlist
            }
            
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    # Extract info and download the video
                    info = ydl.extract_info(video_url, download=True)
                    
                    # Figure out the exact file name yt-dlp generated
                    filename = ydl.prepare_filename(info)
                    base, ext = os.path.splitext(filename)
                    final_filename = base + '.mp4' 
                    
                    # In case the merge output didn't append .mp4 properly, fallback to original name
                    if not os.path.exists(final_filename):
                        final_filename = filename 
                        
                    # Open the file and send it to the user's browser as a download
                    file_handle = open(final_filename, 'rb')
                    return FileResponse(file_handle, as_attachment=True)
                    
            except Exception as e:
                # If an error occurs (e.g., invalid URL, missing FFmpeg), catch it and display it
                context['error'] = f"An error occurred: {str(e)}"
        else:
            context['error'] = "Please provide a valid YouTube URL."

    return render(request, 'index.html', context)

